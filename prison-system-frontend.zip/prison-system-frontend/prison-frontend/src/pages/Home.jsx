import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import api from "../api/axios";
import { useAuth } from "../context/AuthContext";

export default function Home() {
  const { user } = useAuth();
  const [stats, setStats] = useState(null);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (!user) return;
    setLoading(true);
    api
      .get("/reports")
      .then((res) => setStats(res.data))
      .catch(() => setError("Could not load live stats."))
      .finally(() => setLoading(false));
  }, [user]);

  // Logged out: simple welcome screen
  if (!user) {
    return (
      <div className="page">
        <div className="hero">
          <h1>Prison Management System</h1>
          <p>
            A central place for facility staff to manage cells, prisoner
            records, and personnel — with search, validation, and reporting
            built in.
          </p>
          <div className="hero-actions">
            <Link className="btn btn-gold" to="/login">
              Staff Login
            </Link>
            <Link className="btn btn-ghost" to="/about">
              Learn More
            </Link>
          </div>
        </div>

        <div className="grid grid-3" style={{ marginTop: "2rem" }}>
          <div className="card">
            <h3>Prisoner Records</h3>
            <p style={{ color: "var(--muted)" }}>
              Track full name, age, crime, sentence length, and cell
              assignment for every prisoner.
            </p>
          </div>
          <div className="card">
            <h3>Cell Allocation</h3>
            <p style={{ color: "var(--muted)" }}>
              Manage cell capacity and availability so intake decisions are
              fast and accurate.
            </p>
          </div>
          <div className="card">
            <h3>Staff Directory</h3>
            <p style={{ color: "var(--muted)" }}>
              Keep an up-to-date list of facility staff, roles, and contact
              numbers.
            </p>
          </div>
        </div>
      </div>
    );
  }

  // Logged in: dashboard with live stats
  const occupancyPct =
    stats && stats.totalCells > 0
      ? Math.round((stats.occupiedCells / stats.totalCells) * 100)
      : 0;

  return (
    <div className="page">
      <div className="page-header">
        <div>
          <h1>Welcome back, {user.username}</h1>
          <p>Here's a quick snapshot of the facility right now.</p>
        </div>
        <Link className="btn btn-ghost" to="/reports">
          Full Report →
        </Link>
      </div>

      {loading && <p style={{ color: "var(--muted)" }}>Loading dashboard...</p>}
      {error && <div className="form-error-banner">{error}</div>}

      {stats && (
        <>
          <div className="grid grid-3">
            <div className="stat-card">
              <div className="stat-value">{stats.totalPrisoners}</div>
              <div className="stat-label">Total Prisoners</div>
            </div>
            <div className="stat-card">
              <div className="stat-value">{stats.totalStaff}</div>
              <div className="stat-label">Total Staff</div>
            </div>
            <div className="stat-card">
              <div className="stat-value">{stats.totalCells}</div>
              <div className="stat-label">Total Cells</div>
            </div>
          </div>

          <div className="card" style={{ marginTop: "1.5rem" }}>
            <h3 style={{ marginTop: 0 }}>Cell Occupancy</h3>
            <p style={{ color: "var(--muted)", marginTop: 0 }}>
              {stats.occupiedCells} occupied / {stats.availableCells} available
              ({occupancyPct}% occupied)
            </p>
            <div
              style={{
                background: "var(--navy-700)",
                borderRadius: "999px",
                height: "14px",
                overflow: "hidden",
              }}
            >
              <div
                style={{
                  width: `${occupancyPct}%`,
                  height: "100%",
                  background:
                    "linear-gradient(90deg, var(--gold-500), var(--gold-400))",
                }}
              />
            </div>
          </div>
        </>
      )}

      <div className="grid grid-3" style={{ marginTop: "1.5rem" }}>
        <Link to="/prisoners" className="card" style={{ textDecoration: "none" }}>
          <h3 style={{ color: "var(--ink)" }}>Manage Prisoners →</h3>
          <p style={{ color: "var(--muted)", margin: 0 }}>
            View, add, edit, or search prisoner records.
          </p>
        </Link>
        <Link to="/cells" className="card" style={{ textDecoration: "none" }}>
          <h3 style={{ color: "var(--ink)" }}>Manage Cells →</h3>
          <p style={{ color: "var(--muted)", margin: 0 }}>
            Update cell capacity and availability.
          </p>
        </Link>
        <Link to="/staff" className="card" style={{ textDecoration: "none" }}>
          <h3 style={{ color: "var(--ink)" }}>Manage Staff →</h3>
          <p style={{ color: "var(--muted)", margin: 0 }}>
            Keep the personnel directory current.
          </p>
        </Link>
      </div>
    </div>
  );
}
