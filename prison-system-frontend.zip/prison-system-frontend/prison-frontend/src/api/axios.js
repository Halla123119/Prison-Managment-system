import axios from "axios";

// Matches the ASP.NET Core backend's "https" launch profile
// (Properties/launchSettings.json). Run the backend with:
//   dotnet run --launch-profile https
// and trust the dev cert once with:
//   dotnet dev-certs https --trust
//
// If you'd rather run plain HTTP, comment out app.UseHttpsRedirection()
// in the backend's Program.cs and change this to:
//   http://localhost:5232/api
const api = axios.create({
  baseURL: "https://localhost:7229/api",
  headers: {
    "Content-Type": "application/json",
  },
});

export default api;
